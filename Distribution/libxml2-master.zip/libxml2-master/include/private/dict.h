#ifndef XML_DICT_H_PRIVATE__
#define XML_DICT_H_PRIVATE__

int __xmlInitializeDict(void);
int __xmlRandom(void);

#endif /* XML_DICT_H_PRIVATE__ */
